package com.example.simcitycompanion

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.*
import android.widget.*

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private val handler = Handler(Looper.getMainLooper())
    private var seconds = 0
    private var running = false
    private var timerText: TextView? = null
    private val tick = object : Runnable {
        override fun run() {
            if (running) { seconds++; updateTimer(); handler.postDelayed(this, 1000) }
        }
    }
    private val bg = Color.rgb(29, 36, 50)
    private val card = Color.rgb(24, 30, 43)
    private val cyan = Color.rgb(40, 183, 204)
    private val white = Color.rgb(235, 241, 248)

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotification()
        showBubble()
    }

    private fun createNotification() {
        val channel = "simcity_overlay"
        if (Build.VERSION.SDK_INT >= 26) {
            val nc = NotificationChannel(channel, "Menu flutuante", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(nc)
        }
        val n = Notification.Builder(this, channel)
            .setContentTitle("SimCity PlatMod Menu")
            .setContentText("Menu auxiliar ativo. Toque no ícone flutuante para abrir.")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(7, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(7, n)
    }

    private fun lp(): WindowManager.LayoutParams = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.END; x = 18; y = 220 }

    private fun showBubble() {
        if (bubble != null) return
        val b = TextView(this).apply {
            text = "SC"; textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setTypeface(null, Typeface.BOLD); setBackgroundColor(cyan); setPadding(18, 14, 18, 14)
            setOnClickListener { if (panel == null) showPanel() else hidePanel() }
        }
        bubble = b
        wm.addView(b, lp())
    }

    private fun showPanel() {
        if (panel != null) return
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(18, 18, 18, 18); setBackgroundColor(Color.rgb(17, 21, 30))
        }
        val title = TextView(this).apply {
            text = "SIMCITY PLATMODS\nThe City Companion"; textSize = 20f; gravity = Gravity.CENTER
            setTextColor(cyan); setTypeface(null, Typeface.BOLD); setPadding(4, 8, 4, 16)
        }
        outer.addView(title)
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8, 4, 8, 4); setBackgroundColor(bg) }
        content.addView(section("PRODUÇÃO"))
        content.addView(label("Cronômetro de produção"))
        timerText = label("00:00:00")
        content.addView(timerText)
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        controls.addView(action("INICIAR") { if (!running) { running = true; handler.post(tick) } })
        controls.addView(action("PAUSAR") { running = false; handler.removeCallbacks(tick) })
        controls.addView(action("ZERAR") { running = false; handler.removeCallbacks(tick); seconds = 0; updateTimer() })
        content.addView(controls)
        content.addView(section("ANOTAÇÕES DA CIDADE"))
        content.addView(label("Registre manualmente seus recursos e metas. As informações ficam neste aparelho."))
        val notes = EditText(this).apply {
            hint = "Ex.: preciso de 12 pregos e 8 tábuas..."; setTextColor(white); setHintTextColor(Color.LTGRAY)
            setBackgroundColor(card); minLines = 3; setPadding(12, 10, 12, 10)
            setText(getSharedPreferences("city", MODE_PRIVATE).getString("notes", ""))
        }
        content.addView(notes)
        content.addView(action("SALVAR ANOTAÇÕES") { getSharedPreferences("city", MODE_PRIVATE).edit().putString("notes", notes.text.toString()).apply(); Toast.makeText(this, "Anotações salvas", Toast.LENGTH_SHORT).show() })
        content.addView(section("ATALHOS"))
        content.addView(label("Este menu é independente e não altera moedas, SimCash, compras ou dados internos do jogo."))
        scroll.addView(content)
        outer.addView(scroll, LinearLayout.LayoutParams(340, 560))
        outer.addView(action("HIDE / FECHAR PAINEL") { hidePanel() })
        panel = outer
        val p = lp().apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; x = 0; y = 100; flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN }
        wm.addView(outer, p)
    }

    private fun section(s: String) = TextView(this).apply { text = "⌄ $s ⌄"; textSize = 16f; setTextColor(white); setTypeface(null, Typeface.BOLD); setPadding(10, 16, 8, 10) }
    private fun label(s: String) = TextView(this).apply { text = s; textSize = 15f; setTextColor(white); setPadding(12, 12, 12, 12); setBackgroundColor(card) }
    private fun action(s: String, click: () -> Unit) = Button(this).apply { text = s; setTextColor(white); setOnClickListener { click() } }
    private fun updateTimer() { val h = seconds / 3600; val m = (seconds % 3600) / 60; val s = seconds % 60; timerText?.text = "%02d:%02d:%02d".format(h,m,s) }
    private fun hidePanel() { panel?.let { wm.removeView(it) }; panel = null; timerText = null }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        bubble?.let { wm.removeView(it) }; panel?.let { wm.removeView(it) }
        bubble = null; panel = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
