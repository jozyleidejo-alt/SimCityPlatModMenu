package com.example.simcitycompanion

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(21, 26, 37)
        window.navigationBarColor = Color.rgb(21, 26, 37)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(Color.rgb(21, 26, 37))
        }
        root.addView(TextView(this).apply {
            text = "SIMCITY PLATMOD MENU\n\nCompanion flutuante"
            textSize = 24f; setTextColor(Color.rgb(72, 197, 219)); gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "Acompanhe cronômetros de produção e anotações da sua cidade enquanto joga. Este app não altera o SimCity BuildIt nem gera moedas ou itens."
            textSize = 16f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; setPadding(0, 24, 0, 24)
        })
        root.addView(Button(this).apply {
            text = "ATIVAR MENU FLUTUANTE"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else {
                    val intent = Intent(this@MainActivity, OverlayService::class.java)
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
                    finish()
                }
            }
        })
        setContentView(root)
    }
}
