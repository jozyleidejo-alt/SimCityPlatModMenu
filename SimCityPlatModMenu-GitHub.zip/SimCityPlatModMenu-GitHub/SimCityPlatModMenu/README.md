# SimCity PlatMod Menu — Companion Android

Projeto Android Studio em Kotlin para um painel flutuante independente, inspirado visualmente no menu mostrado pelo usuário.

## Recursos incluídos
- Ícone flutuante para abrir/fechar o painel.
- Cronômetro manual de produção com iniciar, pausar e zerar.
- Campo de anotações da cidade salvo localmente.
- Tema escuro com detalhes azul-turquesa.

## Limitações importantes
Este é um app auxiliar. Não injeta código no SimCity BuildIt, não lê nem altera a memória/rede do jogo, não gera Simoleons/SimCash/itens, não libera compras e não remove anúncios. O cronômetro é manual e não detecta automaticamente os tempos do jogo.

## Como gerar o APK
1. Abra a pasta `SimCityPlatModMenu` no Android Studio (versão recente).
2. Aguarde a sincronização do Gradle e a instalação do Android SDK 35, se solicitado.
3. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. O APK de teste será criado em `app/build/outputs/apk/debug/app-debug.apk`.
5. Instale no Android e permita **Exibir sobre outros apps** quando solicitado pelo sistema.

O Android pode solicitar permissão de notificação/serviço em primeiro plano, conforme a versão do sistema.
